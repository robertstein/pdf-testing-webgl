Source: FreeSVG.org
License: Public Domain / CC0-style statement on each asset page.
Download endpoint used: https://freesvg.org/download/<SVG_ID>
Verify each asset page before redistribution.
